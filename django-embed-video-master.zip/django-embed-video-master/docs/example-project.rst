Example project
===============

For easy start with using django-embed-video, you can take a look at example
project. It is located in example_project directory in root of repository.

.. include:: ../example_project/README.rst
