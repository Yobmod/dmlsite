Contributing
============

I will be really pleased if you will provide patch to this Django app. Feel free
to change whatever, but keep `PEP8 <http://www.python.org/dev/peps/pep-0008/>`_
rules and `Zen <http://www.python.org/dev/peps/pep-0020/>`_.

It is a good habit to cover your patches with :doc:`tests <testing>`.

Repository is hosted on Github:
https://github.com/yetty/django-embed-video


