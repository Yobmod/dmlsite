Websites using django-embed-video
=================================

- `Tchorici.cz <http://www.tchorici.cz>`_
- `Tiempoturco.com <http://www.tiempoturco.com>`_

*Are you using django-embed-video? Send pull request!*



