API reference
=============


.. toctree::
  :glob:

  embed_video.*
