Template tags
=============

You have to load template tag library first.

.. code-block:: html+django
  
  {% load embed_video_tags %}



.. automodule:: embed_video.templatetags.embed_video_tags
  :members:
