Admin
=====

.. automodule:: embed_video.admin
  :members:
